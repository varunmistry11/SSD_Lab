SELECT o.orderNumber, o.orderDate, p.productName, od.quantityOrdered, od.priceEach
FROM orders o
LEFT JOIN orderdetails od ON o.orderNumber = od.orderNumber
LEFT JOIN products p ON od.productCode = p.productCode;