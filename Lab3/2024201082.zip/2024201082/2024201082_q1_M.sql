SELECT city FROM offices
UNION
SELECT city FROM customers
ORDER BY city;