SELECT e.employeeNumber, e.firstName, e.lastName, e.jobTitle
FROM employees e
LEFT JOIN employees e2 ON e.employeeNumber = e2.reportsTo
WHERE e2.employeeNumber IS NULL;