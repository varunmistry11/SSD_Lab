SELECT customerNumber, customerName, contactLastName, contactFirstName, creditLimit
FROM customers
ORDER BY creditLimit DESC;