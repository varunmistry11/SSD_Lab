Assumptions
B. Most expensive product is selected base on buyPrice.
C. customerNumber, customerName, contactLastName, contactFirstName columns are selected for customer.
D. customerNumber, customerName, contactLastName, contactFirstName columns are selected for customer.
E. employeeNumber, firstName, lastName, jobTitle of employee are selected.
G. customerNumber, customerName, contactLastName, contactFirstName columns are selected for customer.
O. customerNumber, customerName columns of customer are selected.
Q. productCode, productName of product are selected.
