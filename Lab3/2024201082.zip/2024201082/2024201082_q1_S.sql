SELECT pl.productLine, o.officeCode, o.city
FROM productlines pl
CROSS JOIN offices o;