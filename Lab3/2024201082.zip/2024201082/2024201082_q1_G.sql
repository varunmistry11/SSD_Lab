SELECT c.customerNumber, c.customerName, c.contactFirstName, c.contactLastName
FROM customers c 
LEFT JOIN orders o ON c.customerNumber = o.customerNumber
WHERE o.orderNumber IS NULL;