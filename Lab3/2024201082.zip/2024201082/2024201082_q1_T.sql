WITH CustomerSales AS (
    SELECT 
        c.customerNumber,
        c.customerName,
        SUM(od.quantityOrdered * od.priceEach) AS totalSpent
    FROM 
        customers c
    JOIN 
        orders o ON c.customerNumber = o.customerNumber
    JOIN 
        orderdetails od ON o.orderNumber = od.orderNumber
    GROUP BY c.customerNumber, c.customerName
), 
AverageSales AS (
    SELECT AVG(totalSpent) AS avgSales
    FROM CustomerSales
)
SELECT cs.customerNumber, cs.customerName, cs.totalSpent
FROM CustomerSales cs
JOIN AverageSales a ON cs.totalSpent > 2 * a.avgSales;