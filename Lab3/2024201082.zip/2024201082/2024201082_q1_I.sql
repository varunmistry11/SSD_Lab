WITH SalesPerOrder AS (
    SELECT o.orderNumber, c.salesRepEmployeeNumber, SUM(od.quantityOrdered * od.priceEach) AS orderTotal
    FROM orders o
    JOIN orderdetails od ON o.orderNumber = od.orderNumber
    JOIN customers c ON o.customerNumber = c.customerNumber
    GROUP BY o.orderNumber, c.salesRepEmployeeNumber
),
TotalSalesPerEmployee AS (
    SELECT e.employeeNumber, e.firstName, e.lastName, SUM(s.orderTotal) AS totalSales
    FROM SalesPerOrder s
    JOIN employees e ON s.salesRepEmployeeNumber = e.employeeNumber
    GROUP BY e.employeeNumber, e.firstName, e.lastName
)
SELECT employeeNumber, firstName, lastName, totalSales
FROM TotalSalesPerEmployee
ORDER BY totalSales DESC
LIMIT 3;