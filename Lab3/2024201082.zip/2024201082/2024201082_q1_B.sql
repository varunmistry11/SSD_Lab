SELECT productCode, productName, buyPrice
FROM products
ORDER BY buyPrice DESC 
LIMIT 10 OFFSET 5;