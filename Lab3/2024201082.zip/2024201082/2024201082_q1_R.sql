SELECT o.orderNumber, p.productCode, p.productName
FROM orders o
LEFT JOIN orderdetails od ON o.orderNumber = od.orderNumber
LEFT JOIN products p ON od.productCode = p.productCode
ORDER BY o.orderNumber;