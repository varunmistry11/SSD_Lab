SELECT p.productCode, p.productName, od.orderNumber
FROM products p
LEFT JOIN orderdetails od ON p.productCode = od.productCode
ORDER BY p.productCode;