Steps for execution:
1) chmod +x <script_file>.sh
2) ./<script_file>.sh

Question 1
First search for lines with "POST" using grep. Then pipe this output to another grep for "404".

Question 2
Using awk, access 4th column using $4 and calculate total in 'sum'. Print 'sum' at the end using END.