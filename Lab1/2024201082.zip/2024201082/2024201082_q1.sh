#!/bin/bash
grep "POST" access.log | grep "404"