#!/bin/bash
if [ -z $1 ]
then 
    echo "Enter file name as argument"
else
    assignmentName=$1
    filepath=`locate -e $assignmentName`
    if [ -z $filepath ]
    then
        echo "File not found"
    else
        head -n 4 $filepath
    fi
fi