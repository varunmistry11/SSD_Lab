## Question 1
Assumption - file to be searched is unique and is passed as argument to script.
Usage - ./2024201082_q1.sh <file_name>
File is searched using locate command and first 4 lines are printed using head command.

## Question 2
### 2a
Usage - ./2024201082_q2a.sh <n>
Assumption n >= 1

### 2b
Usage -
export A=5
export B=6
./2024201082_q2b.sh
Assumption - Environment variables A and B are set already using export commands as shown above