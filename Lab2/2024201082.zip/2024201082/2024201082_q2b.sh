#!/bin/bash
if [ -z $A ]
then
    echo "A environment variable is not set"
elif [ -z $B ]
then
    echo "B environment variable is not set"
else
    echo "$A+$B" | bc
fi