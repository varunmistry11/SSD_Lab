#!/bin/bash
if [ -z $1 ]
then
    echo "Enter n as argument"
fi
n=$1
prev=0
curr=1
for (( i=0; i<n; i++))
do
    echo -n "$prev "
    new=$((prev+curr))
    prev=$curr
    curr=$new
done